#include "ft_print_numbers.c"

void ft_print_numbers(void);

int	main(void)
{
	ft_print_numbers();
}
