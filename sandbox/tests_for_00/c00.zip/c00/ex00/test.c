#include "ft_putchar.c"

void ft_putchar(char c);

int	main(void)
{
ft_putchar('g');
}
